import { TODAY } from '../data/workspace';
import { Select } from '../components/Select';
import { useCallback, useMemo, useState } from 'react';
import { MembershipTag } from '../components/MembershipTag';
import { ArrowDownWideNarrow, ArrowUpRight, CreditCard, ListFilter, Search, X } from 'lucide-react';
import { Avatar, Button, Modal } from '../components/ui';
import { memberDemographics, visitKinds } from '../data/admin';
import type { AdminSectionId } from '../data/admin';
import { demoClubs } from '../data/roles';
import type { Member, Visit } from '../types';
import { useWorkspace } from '../components/WorkspaceProvider';
import { useTheme } from '../components/ThemeProvider';
import { MinimalVisitorTable } from '../components/MinimalVisitorTable';

const initialFilters = (clubId: string) => ({
  clubId,
  kind: 'all',
  gender: 'all',
  age: '',
  fromDate: TODAY,
  fromTime: '00:00',
  toDate: TODAY,
  toTime: '23:59',
});

export function AdminOverview({
  visits,
  members,
  clubId,
  onMember,
  onAction,
}: {
  visits: Visit[];
  members: Member[];
  clubId: string;
  onMember: (member: Member) => void;
  onAction: (id: AdminSectionId) => void;
}) {
  const { data } = useWorkspace();
  const { visualStyle } = useTheme();
  const minimal = visualStyle === 'spectrum';
  const currentShift = data.shifts.find(
    (row) => row.club === demoClubs.find((club) => club.id === clubId)?.shortName,
  );
  const [query, setQuery] = useState('');
  const [expanded, setExpanded] = useState(false);
  const [filters, setFilters] = useState(() => initialFilters(clubId));
  const [draft, setDraft] = useState(filters);
  const [unique, setUnique] = useState(false);
  const [sort, setSort] = useState('time');
  const [draftUnique, setDraftUnique] = useState(unique);
  const [draftSort, setDraftSort] = useState(sort);
  const [filterError, setFilterError] = useState('');
  const closeFilters = useCallback(() => setExpanded(false), []);
  const memberMap = useMemo(() => new Map(members.map((m) => [m.id, m])), [members]);
  const filtered = useMemo(() => {
    const found = visits
      .filter((v) => {
        const member = memberMap.get(v.memberId);
        const demographic = memberDemographics[v.memberId];
        return (
          member &&
          (filters.clubId === 'all' || v.clubId === filters.clubId) &&
          (filters.kind === 'all' || v.kind === filters.kind) &&
          (filters.gender === 'all' || demographic?.gender === filters.gender) &&
          (!filters.age || demographic?.age === Number(filters.age)) &&
          v.enteredAt >= `${filters.fromDate}T${filters.fromTime || '00:00'}` &&
          v.enteredAt <= `${filters.toDate}T${filters.toTime || '23:59'}` &&
          `${member.name} ${v.card}`.toLowerCase().includes(query.trim().toLowerCase())
        );
      })
      .sort((a, b) => b.enteredAt.localeCompare(a.enteredAt));
    const seen = new Set<number>();
    const rows = unique
      ? found.filter((v) => {
          if (seen.has(v.memberId)) return false;
          seen.add(v.memberId);
          return true;
        })
      : found;
    return sort === 'name'
      ? [...rows].sort((a, b) =>
          memberMap
            .get(a.memberId)!
            .name.split(' ')
            .at(-1)!
            .localeCompare(memberMap.get(b.memberId)!.name.split(' ').at(-1)!, 'ru'),
        )
      : rows;
  }, [visits, memberMap, filters, query, unique, sort]);
  const showVisitClubs = !minimal || filtered.some((visit) => visit.clubId !== clubId);
  const activeCount =
    Number(unique) +
    Number(sort !== 'time') +
    Number(filters.kind !== 'all') +
    Number(filters.gender !== 'all') +
    Number(!!filters.age) +
    Number(filters.clubId !== clubId) +
    Number(
      filters.fromDate !== TODAY ||
        filters.toDate !== TODAY ||
        filters.fromTime !== '00:00' ||
        filters.toTime !== '23:59',
    );
  const resetFilters = () => {
    const next = initialFilters(clubId);
    setFilters(next);
    setDraft(next);
    setQuery('');
    setUnique(false);
    setSort('time');
    setFilterError('');
  };
  const field = (name: keyof typeof filters, value: string) =>
    setDraft((prev) => ({ ...prev, [name]: value }));
  return (
    <div className="reception-home">
      {minimal && (
        <div className="minimal-reception-summary">
          <div>
            <strong>{filtered.length}</strong>
            <span>посещений</span>
          </div>
          <button
            title={currentShift?.status ? `Статус смены: ${currentShift.status}` : undefined}
            onClick={() => onAction('payroll')}
          >
            <span>Смена</span>
            <strong>
              {currentShift
                ? `${currentShift.start.split('T')[1]}–${currentShift.end.split('T')[1]}`
                : 'Не запланирована'}{' '}
              <ArrowUpRight size={15} />
            </strong>
          </button>
        </div>
      )}
      <div className="panel ws-home-shift">
        <span>
          <strong>Моя смена</strong>
          <small>
            {currentShift
              ? `${currentShift.start.split('T')[1]}–${currentShift.end.split('T')[1]} · ${currentShift.status}`
              : 'Нет запланированной смены'}
          </small>
        </span>
        <Button variant="ghost" onClick={() => onAction('payroll')}>
          Рабочий день
          <ArrowUpRight size={14} />
        </Button>
      </div>
      <details className="reception-mobile-shift">
        <summary>
          Моя смена{' '}
          <span>
            {currentShift
              ? `${currentShift.start.split('T')[1]}–${currentShift.end.split('T')[1]}`
              : 'Не запланирована'}
          </span>
        </summary>
        <span>{currentShift?.status}</span>
        <Button variant="ghost" onClick={() => onAction('payroll')}>
          Открыть рабочий день <ArrowUpRight size={14} />
        </Button>
      </details>
      <div className="admin-home-grid">
        <section className="panel visitor-panel">
          {!minimal && (
            <div className="visitor-heading">
              <div>
                <h2>
                  Недавние посетители <span>{filtered.length}</span>
                </h2>
              </div>
              <span className="visitor-live">
                <i />
                Обновлено в 14:35
              </span>
            </div>
          )}
          <div className="visitor-toolbar">
            <label className="visitor-search">
              <Search size={17} />
              <input
                aria-label="Найти посетителя"
                placeholder="Имя клиента или номер карты"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
              {query && (
                <button
                  className="icon-button"
                  aria-label="Очистить поиск посетителей"
                  onClick={() => setQuery('')}
                >
                  <X size={14} />
                </button>
              )}
            </label>
            <button
              className={`visitor-filter-button ${expanded || activeCount ? 'active' : ''}`}
              aria-expanded={expanded}
              aria-haspopup="dialog"
              onClick={() => {
                setDraft(filters);
                setDraftUnique(unique);
                setDraftSort(sort);
                setFilterError('');
                setExpanded(true);
              }}
            >
              <ListFilter size={16} />
              Фильтры{activeCount > 0 && <b>{activeCount}</b>}
            </button>
            {minimal && (
              <div className="minimal-journal-options">
                <button
                  className="minimal-unique-toggle"
                  aria-pressed={unique}
                  onClick={() => setUnique(!unique)}
                >
                  Без повторов
                </button>
                <Select
                  aria-label="Сортировка посетителей"
                  value={sort}
                  onChange={(e) => setSort(e.target.value)}
                >
                  <option value="time">Сначала новые</option>
                  <option value="name">По фамилии</option>
                </Select>
              </div>
            )}
          </div>
          {expanded && (
            <Modal title="Фильтры посещений" onClose={closeFilters}>
              <form
                className="visitor-filters"
                onSubmit={(e) => {
                  e.preventDefault();
                  const form = new FormData(e.currentTarget);
                  const next = {
                    fromDate: String(form.get('fromDate')),
                    fromTime: String(form.get('fromTime') || '00:00'),
                    toDate: String(form.get('toDate')),
                    toTime: String(form.get('toTime') || '23:59'),
                    clubId: String(form.get('clubId')),
                    kind: String(form.get('kind')),
                    gender: String(form.get('gender')),
                    age: String(form.get('age') || ''),
                  };
                  if (`${next.fromDate}T${next.fromTime}` > `${next.toDate}T${next.toTime}`) {
                    setFilterError('Начало периода должно быть раньше конца.');
                    return;
                  }
                  setDraft(next);
                  setFilters(next);
                  setUnique(draftUnique);
                  setSort(draftSort);
                  setFilterError('');
                  setExpanded(false);
                }}
              >
                <div className="filter-date-group">
                  <label>
                    С даты
                    <input
                      aria-label="Посещения с даты"
                      name="fromDate"
                      type="date"
                      required
                      value={draft.fromDate}
                      onChange={(e) => field('fromDate', e.target.value)}
                    />
                  </label>
                  <label>
                    Время
                    <input
                      aria-label="Посещения с времени"
                      name="fromTime"
                      type="time"
                      value={draft.fromTime}
                      onChange={(e) => field('fromTime', e.target.value)}
                    />
                  </label>
                  <label>
                    По дату
                    <input
                      aria-label="Посещения по дату"
                      name="toDate"
                      type="date"
                      required
                      value={draft.toDate}
                      onChange={(e) => field('toDate', e.target.value)}
                    />
                  </label>
                  <label>
                    Время
                    <input
                      aria-label="Посещения по время"
                      name="toTime"
                      type="time"
                      value={draft.toTime}
                      onChange={(e) => field('toTime', e.target.value)}
                    />
                  </label>
                </div>
                <div className="filter-details-group">
                  <label>
                    Клуб
                    <Select
                      aria-label="Клуб посетителей"
                      name="clubId"
                      value={draft.clubId}
                      onChange={(e) => field('clubId', e.target.value)}
                    >
                      <option value="all">Все клубы</option>
                      {demoClubs.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.name}
                        </option>
                      ))}
                    </Select>
                  </label>
                  <label>
                    Посещение
                    <Select
                      aria-label="Тип посещения"
                      name="kind"
                      value={draft.kind}
                      onChange={(e) => field('kind', e.target.value)}
                    >
                      <option value="all">Все посещения</option>
                      {Object.entries(visitKinds).map(([id, label]) => (
                        <option key={id} value={id}>
                          {label}
                        </option>
                      ))}
                    </Select>
                  </label>
                  <label>
                    Пол
                    <Select
                      aria-label="Пол посетителей"
                      name="gender"
                      value={draft.gender}
                      onChange={(e) => field('gender', e.target.value)}
                    >
                      <option value="all">Любой</option>
                      <option value="male">Мужчины</option>
                      <option value="female">Женщины</option>
                    </Select>
                  </label>
                  <label>
                    Возраст, лет
                    <input
                      aria-label="Возраст посетителя"
                      name="age"
                      type="number"
                      min="0"
                      max="120"
                      placeholder="Любой"
                      value={draft.age}
                      onChange={(e) => field('age', e.target.value)}
                    />
                  </label>
                </div>
                <div className="visitor-mobile-controls">
                  <label className="ws-checkbox">
                    <input
                      type="checkbox"
                      checked={draftUnique}
                      onChange={(event) => setDraftUnique(event.target.checked)}
                    />
                    Только уникальные клиенты
                  </label>
                  <label>
                    Порядок посетителей
                    <Select
                      aria-label="Порядок посетителей в фильтрах"
                      value={draftSort}
                      onChange={(event) => setDraftSort(event.target.value)}
                    >
                      <option value="time">Сначала новые</option>
                      <option value="name">По фамилии</option>
                    </Select>
                  </label>
                </div>
                {filterError && (
                  <p role="alert" className="filter-error">
                    {filterError}
                  </p>
                )}
                <div className="filter-form-actions">
                  <span>Фильтры применяются к журналу посещений</span>
                  <Button type="button" variant="ghost" onClick={closeFilters}>
                    Отмена
                  </Button>
                  <Button
                    type="button"
                    variant="ghost"
                    onClick={() => {
                      setDraft(initialFilters(clubId));
                      setDraftUnique(false);
                      setDraftSort('time');
                      setFilterError('');
                    }}
                  >
                    Сбросить
                  </Button>
                  <Button type="submit">Показать</Button>
                </div>
              </form>
            </Modal>
          )}
          <div className="visitor-table-controls">
            <label>
              <input
                type="checkbox"
                checked={unique}
                onChange={(e) => setUnique(e.target.checked)}
              />
              Только уникальные клиенты
            </label>
            <label className="visitor-sort">
              <ArrowDownWideNarrow size={13} />
              <Select
                aria-label="Сортировка посетителей"
                value={sort}
                onChange={(e) => setSort(e.target.value)}
              >
                <option value="time">Сначала новые</option>
                <option value="name">По фамилии</option>
              </Select>
            </label>
          </div>
          {filtered.length ? (
            <>
              <div
                className="visitor-table-scroll"
                role="region"
                aria-label="Журнал посетителей"
                tabIndex={0}
              >
                {minimal ? (
                  <MinimalVisitorTable
                    visits={filtered}
                    members={memberMap}
                    onMember={onMember}
                    currentClubId={clubId}
                  />
                ) : (
                  <table className="visitor-table">
                    <thead>
                      <tr>
                        <th>№</th>
                        <th>Время входа</th>
                        <th>Карта</th>
                        <th>Клиент</th>
                        <th>Посещение</th>
                        <th>Абонемент</th>
                        <th>Клуб</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filtered.map((v, i) => {
                        const member = memberMap.get(v.memberId)!;
                        return (
                          <tr
                            key={v.id}
                            className="is-openable"
                            onClick={(event) => {
                              if (!(event.target as HTMLElement).closest('button, a'))
                                onMember(member);
                            }}
                          >
                            <td>{String(i + 1).padStart(2, '0')}</td>
                            <td>
                              <time dateTime={v.enteredAt}>{v.enteredAt.slice(11)}</time>
                              {v.enteredAt.slice(0, 10) !== TODAY && (
                                <small>
                                  {v.enteredAt.slice(8, 10)}.{v.enteredAt.slice(5, 7)}
                                </small>
                              )}
                            </td>
                            <td>
                              <button
                                className="visitor-card-link"
                                onClick={() => onMember(member)}
                              >
                                {v.card}
                              </button>
                            </td>
                            <td>
                              <button
                                className="visitor-member-button"
                                onClick={() => onMember(member)}
                              >
                                {!minimal && <Avatar member={member} />}
                                <span>
                                  <strong>{member.name}</strong>
                                </span>
                              </button>
                            </td>
                            <td>
                              <span className={`visit-kind visit-kind-${v.kind}`}>
                                {visitKinds[v.kind]}
                              </span>
                            </td>
                            <td>
                              <MembershipTag name={v.plan} textOnly />
                            </td>
                            <td>{demoClubs.find((c) => c.id === v.clubId)?.shortName}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                )}
              </div>
              <div className="visitor-mobile-list">
                {filtered.map((v) => {
                  const member = memberMap.get(v.memberId)!;
                  return (
                    <article key={v.id} className="visitor-mobile-card">
                      <div>
                        {!minimal && <Avatar member={member} />}
                        <button onClick={() => onMember(member)}>
                          <strong>{member.name}</strong>
                          <span>
                            {minimal ? v.card : `Карта ${v.card}`}
                            {!minimal && <ArrowUpRight size={11} />}
                          </span>
                        </button>
                        <time>{v.enteredAt.slice(11)}</time>
                      </div>
                      <dl>
                        <div>
                          <dt>Посещение</dt>
                          <dd>{visitKinds[v.kind]}</dd>
                        </div>
                        <div>
                          <dt>Абонемент</dt>
                          <dd>
                            <MembershipTag name={v.plan} textOnly />
                          </dd>
                        </div>
                        {showVisitClubs && (
                          <div>
                            <dt>Клуб</dt>
                            <dd>{demoClubs.find((c) => c.id === v.clubId)?.shortName}</dd>
                          </div>
                        )}
                      </dl>
                    </article>
                  );
                })}
              </div>
            </>
          ) : (
            <div className="visitor-no-results">
              <Search size={28} />
              <h3>Посещений не найдено</h3>
              <p>Попробуйте другой запрос или измените фильтры.</p>
              <Button variant="secondary" onClick={resetFilters}>
                Сбросить фильтры
              </Button>
            </div>
          )}
          <div className="visitor-footer">
            <span>
              Показано посещений: <strong>{filtered.length}</strong>
            </span>
            <span>{new Set(filtered.map((v) => v.memberId)).size} уникальных клиентов</span>
          </div>
          <div className="visitor-hint">
            <CreditCard size={14} />
            <span>Нажмите на карту или имя, чтобы открыть карточку клиента.</span>
          </div>
        </section>
      </div>
    </div>
  );
}
