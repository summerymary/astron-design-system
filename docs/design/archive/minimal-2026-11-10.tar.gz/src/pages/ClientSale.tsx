import { demoStamp, nextDemoNow } from '../lib/demo-clock';
import { Select } from '../components/Select';
import { useCallback, useEffect, useRef, useState } from 'react';
import { ArrowLeft, Banknote, CreditCard, Gift, Layers, Search, Wallet, X } from 'lucide-react';
import type { Member } from '../types';
import type { Navigate } from '../components/WorkspaceUI';
import { Button, Modal } from '../components/ui';
import { Notice, Empty } from '../components/WorkspaceUI';
import { ClientSearch } from '../components/ClientSearch';
import { demoId, useWorkspace } from '../components/WorkspaceProvider';
import { MembershipCard } from '../components/MembershipCard';
import { CatalogSectionCard } from '../components/CatalogSectionCard';
import { quantityLabel } from '../data/membership-kinds';
import { memberCards } from '../data/admin';
import { money, TODAY } from '../data/workspace';
import type { DemoRecord } from '../data/workspace';
import { paymentMethods, paymentPlan, saleTotal } from '../lib/checkout';
import type { PaymentMethod, PaymentParts } from '../lib/checkout';

import { saleCatalog, saleSections, searchSaleCatalog } from '../lib/sale-catalog';
import type { SaleCatalogItem, SaleSectionId } from '../lib/sale-catalog';
const methodIcons = [Banknote, CreditCard, Gift, Wallet, Layers];
export function SaleWorkspace({
  members,
  initialMember,
  navigate,
  clubName,
  employeeName,
  allowRegistration = true,
  initialSection = null,
}: {
  members: Member[];
  initialMember: Member | null;
  navigate: Navigate;
  clubName: string;
  employeeName: string;
  allowRegistration?: boolean;
  initialSection?: SaleSectionId | null;
}) {
  const { data, put } = useWorkspace();
  const saleRoot = useRef<HTMLDivElement>(null);
  const submitArea = useRef<HTMLDivElement>(null);
  const [saleStep, setSaleStep] = useState<'client' | 'catalog' | 'payment'>(
    initialMember ? 'catalog' : 'client',
  );
  const [clientSearchOpen, setClientSearchOpen] = useState(!initialMember);
  const [memberId, setMemberId] = useState(String(initialMember?.id || ''));
  const [sectionId, setSectionId] = useState<SaleSectionId | null>(initialSection);
  const [query, setQuery] = useState('');
  const [itemId, setItemId] = useState('');
  const [quantity, setQuantity] = useState('1');
  const [discount, setDiscount] = useState('0');
  const [method, setMethod] = useState<PaymentMethod>('Безналичная оплата');
  const [parts, setParts] = useState<PaymentParts>({ cash: 0, card: 0, gift: 0, credit: 0 });
  const [giftId, setGiftId] = useState('');
  const [printReceipt, setPrintReceipt] = useState(true);
  const [receipt, setReceipt] = useState<DemoRecord | null>(null);
  const [receiptOpen, setReceiptOpen] = useState(false);
  const closeReceipt = useCallback(() => setReceiptOpen(false), []);
  const [done, setDone] = useState(false);
  const [error, setError] = useState('');
  const [debt, setDebt] = useState(0);
  useEffect(() => {
    if (saleStep !== 'payment' || !saleRoot.current || saleRoot.current.clientWidth > 740) return;
    const frame = requestAnimationFrame(() => submitArea.current?.scrollIntoView({ block: 'end' }));
    return () => cancelAnimationFrame(frame);
  }, [saleStep, itemId, method]);
  const member = members.find((member) => String(member.id) === memberId);
  const catalog = saleCatalog(data);
  const selected = catalog.find((entry) => entry.record.id === itemId);
  const item = selected?.record;
  const isPlan = selected?.type === 'plan';
  const category =
    selected?.type === 'product'
      ? 'Товары'
      : selected?.type === 'service'
        ? 'Услуги'
        : saleSections.find((section) => section.id === selected?.sectionId)?.name || 'Абонементы';
  const visibleItems = searchSaleCatalog(catalog, query, sectionId);
  const currentSection = saleSections.find((section) => section.id === sectionId);
  let pricing = { base: 0, discount: 0, total: 0 };
  let calculationError = '';
  try {
    if (item) pricing = saleTotal(Number(item.price), Number(quantity), Number(discount));
  } catch (err) {
    calculationError = err instanceof Error ? err.message : 'Проверьте сумму.';
  }
  useEffect(() => setParts({ cash: 0, card: pricing.total, gift: 0, credit: 0 }), [pricing.total]);
  const gift = (data['gift-cards'] || []).find(
    (row) => row.id === giftId && row.status === 'Активна',
  );
  const clearResult = () => {
    setDone(false);
    setError('');
    setReceipt(null);
    setReceiptOpen(false);
    setDebt(0);
  };
  const confirm = () => {
    if (!member || !item || done || calculationError) return;
    try {
      const payment = paymentPlan(
        pricing.total,
        method,
        parts,
        gift ? Number(gift.balance) : undefined,
      );
      if (
        category === 'Товары' &&
        (!Number.isFinite(Number(item.stock)) || Number(item.stock) < Number(quantity))
      )
        throw new Error('Недостаточно товара. Уменьшите количество.');
      const id = demoId('sale');
      const paid = Math.round((pricing.total - payment.credit) * 100) / 100;
      const stamp = demoStamp(nextDemoNow());
      const details: DemoRecord = {
        id,
        name: item.name,
        description: item.short || item.description || item.name,
        category,
        date: stamp.slice(0, 10),
        time: stamp.slice(11),
        cashier: employeeName,
        receiptNumber: printReceipt ? `DEMO-${id.slice(-8).toUpperCase()}` : '',
        club: clubName.split(' · ').at(-1) || 'Центральный',
        client: member.fullName || member.name,
        memberId,
        amount: String(paid),
        total: String(pricing.total),
        basePrice: String(pricing.base),
        discount: String(discount),
        discountAmount: String(pricing.discount),
        quantity,
        method,
        cashAmount: String(payment.cash),
        cardAmount: String(payment.card),
        giftAmount: String(payment.gift),
        creditAmount: String(payment.credit),
        status: payment.credit ? (paid ? 'Частичная оплата' : 'В долг') : 'Оплачено',
        receiptRequested: String(printReceipt),
      };
      put('ledger', details);
      if (payment.gift && gift)
        put('gift-cards', {
          ...gift,
          balance: String(Math.round((Number(gift.balance) - payment.gift) * 100) / 100),
        });
      if (payment.credit)
        put('receivables', {
          id: `debt-${id}`,
          memberId,
          name: member.name,
          saleId: id,
          amount: String(payment.credit),
          date: TODAY,
          status: 'Не погашено',
        });
      if (isPlan) put('issued-plans', { ...item, id: demoId('issued'), memberId, issued: TODAY });
      else if (category === 'Товары')
        put('retail-products', { ...item, stock: String(Number(item.stock) - Number(quantity)) });
      else put('issued-services', { ...item, id: demoId('service'), memberId, issued: TODAY });
      if (printReceipt) {
        const next = {
          ...details,
          id: `receipt-${id}`,
          saleId: id,
          card: memberCards[member.id] || String(member.id + 99000),
        };
        put('receipts', next);
        setReceipt(next);
      }
      setDebt(payment.credit);
      setDone(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Не удалось подтвердить продажу.');
    }
  };
  const openSection = (id: SaleSectionId | null) => {
    setSectionId(id);
    setQuery('');
    setItemId('');
    setQuantity('1');
    setDiscount('0');
    clearResult();
  };
  const renderItem = (entry: SaleCatalogItem) => {
    const row = entry.record;
    return (
      <button
        className="plastic-choice"
        aria-pressed={itemId === row.id}
        key={row.id}
        onClick={() => {
          setSectionId(entry.sectionId);
          setItemId(row.id);
          setSaleStep(member ? 'payment' : 'client');
          setQuantity('1');
          setDiscount('0');
          clearResult();
        }}
      >
        {entry.type === 'plan' ? (
          <MembershipCard
            compact
            name={row.name}
            kindId={row.kindId}
            detail={
              row.type === 'Безлимитный'
                ? `${quantityLabel(row.duration, 'day')} · без ограничений`
                : `${quantityLabel(row.visits, 'visit')} · ${quantityLabel(row.duration, 'day')}`
            }
            footer={money(row.price)}
          />
        ) : (
          <span className="sale-item">
            <small>{entry.type === 'product' ? 'Товар ресепшена' : 'Услуга'}</small>
            <strong>{row.name}</strong>
            <span>{money(row.price)}</span>
            {entry.type === 'product' && (
              <small>
                Остаток ({row.unit}): {row.stock}
              </small>
            )}
          </span>
        )}
      </button>
    );
  };
  return (
    <div ref={saleRoot} className={`sale-workspace sale-step-${saleStep}`}>
      <nav className="sale-step-nav" aria-label="Шаги продажи">
        {(['client', 'catalog', 'payment'] as const).map((step, index) => (
          <button
            key={step}
            aria-current={saleStep === step ? 'step' : undefined}
            disabled={(step === 'catalog' && !member) || (step === 'payment' && (!member || !item))}
            onClick={() => setSaleStep(step)}
          >
            {index + 1}. {['Клиент', 'Покупка', 'Оплата'][index]}
          </button>
        ))}
      </nav>
      <div className="sale-layout">
        <div className="sale-main ws-stack">
          <section className="panel ws-panel client-picker-panel">
            <div className="ws-panel-heading">
              <div>
                <h2>1. Клиент</h2>
                {(!member || clientSearchOpen) && (
                  <p>Найдите клиента по карте, ФИО или номеру телефона.</p>
                )}
              </div>
              {member && (
                <Button variant="ghost" onClick={() => setClientSearchOpen(!clientSearchOpen)}>
                  {clientSearchOpen ? 'Скрыть поиск' : 'Другой клиент'}
                </Button>
              )}
            </div>
            <div className="ws-panel-body ws-stack">
              {(!member || clientSearchOpen) && (
                <ClientSearch
                  mode="selection"
                  purpose="покупки"
                  members={members}
                  onMember={(next) => {
                    setMemberId(String(next.id));
                    setClientSearchOpen(false);
                    setSaleStep('catalog');
                    setDiscount('0');
                    setGiftId('');
                    clearResult();
                  }}
                />
              )}
              {member && (
                <div className="checkout-client">
                  <strong>{member.fullName || member.name}</strong>
                  <span>Карта {memberCards[member.id] || String(member.id + 99000)}</span>
                  <span>
                    {member.phone} · {member.email}
                  </span>
                </div>
              )}
              {member && allowRegistration && (
                <button
                  className="client-text-action"
                  onClick={() => navigate('registration', member)}
                >
                  К регистрации посещения
                </button>
              )}
              {member && (
                <Button className="sale-next" onClick={() => setSaleStep('catalog')}>
                  Выбрать покупку
                </Button>
              )}
            </div>
          </section>
          <section className="panel ws-panel sale-catalog" aria-label="Каталог продажи">
            <div className="ws-panel-heading">
              <div>
                <h2>2. {currentSection?.name || 'Выбор покупки'}</h2>
                <p>
                  {currentSection?.description ||
                    'Выберите раздел или найдите покупку по названию.'}
                </p>
              </div>
            </div>
            <div className="ws-panel-body ws-stack">
              {sectionId && (
                <div className="ws-actions">
                  <Button variant="ghost" onClick={() => openSection(null)}>
                    <ArrowLeft size={16} /> Все разделы продажи
                  </Button>
                </div>
              )}
              <div className="sale-name-search">
                <label htmlFor="sale-name-query">Поиск по названию</label>
                <div>
                  <Search size={20} aria-hidden="true" />
                  <input
                    id="sale-name-query"
                    type="search"
                    value={query}
                    placeholder={
                      sectionId
                        ? 'Название в этом разделе'
                        : 'Абонемент, тренировка, товар или услуга'
                    }
                    onChange={(event) => setQuery(event.target.value)}
                  />
                  {query && (
                    <button
                      type="button"
                      className="icon-button"
                      aria-label="Очистить поиск по названию"
                      onClick={() => setQuery('')}
                    >
                      <X size={18} />
                    </button>
                  )}
                </div>
              </div>
              {!sectionId && !query.trim() ? (
                <div className="sale-section-grid">
                  {saleSections.map((section) => {
                    const count = catalog.filter((entry) => entry.sectionId === section.id).length;
                    return (
                      <CatalogSectionCard
                        key={section.id}
                        id={section.id}
                        count={count}
                        onClick={() => openSection(section.id)}
                      />
                    );
                  })}
                </div>
              ) : visibleItems.length ? (
                <>
                  <p className="form-note" role="status">
                    Найдено позиций: {visibleItems.length}
                  </p>
                  {saleSections
                    .filter((section) =>
                      visibleItems.some((entry) => entry.sectionId === section.id),
                    )
                    .map((section) => {
                      const entries = visibleItems.filter(
                        (entry) => entry.sectionId === section.id,
                      );
                      return (
                        <div className="ws-stack" key={section.id}>
                          {!sectionId && <h3>{section.name}</h3>}
                          <div
                            className={`plastic-card-grid ${section.id === 'goods-services' ? 'sale-item-grid' : ''}`}
                          >
                            {entries.map(renderItem)}
                          </div>
                        </div>
                      );
                    })}
                </>
              ) : (
                <Empty
                  title={query.trim() ? 'Ничего не найдено' : 'Пока нет позиций'}
                  text={
                    query.trim()
                      ? 'Попробуйте другое название или более короткий запрос.'
                      : sectionId === 'exceptions'
                        ? 'Позиции и правила этого раздела будут уточнены.'
                        : 'Доступные позиции появятся после добавления в каталог.'
                  }
                  action={
                    query.trim() ? (
                      <Button variant="secondary" onClick={() => setQuery('')}>
                        Сбросить поиск
                      </Button>
                    ) : undefined
                  }
                />
              )}
            </div>
          </section>
        </div>
        {saleStep === 'payment' && member && item && (
          <section className="panel ws-panel checkout-panel">
            <div className="ws-panel-heading">
              <h2>3. Оплата</h2>
              <Button
                className="sale-next"
                variant="ghost"
                onClick={() => {
                  setSaleStep('catalog');
                  saleRoot.current?.scrollIntoView({ block: 'start' });
                }}
              >
                <ArrowLeft size={16} /> К покупке
              </Button>
            </div>
            <div className="ws-panel-body ws-stack">
              {member && item ? (
                <>
                  <div className="checkout-options ws-stack">
                    <div className="checkout-review ws-stack">
                      <div className="checkout-summary">
                        <strong>{item.name}</strong>
                        <span>
                          {member.name} · карта{' '}
                          {memberCards[member.id] || String(member.id + 99000)}
                        </span>
                        <span>За единицу: {money(item.price)}</span>
                      </div>
                      <details className="checkout-contact-details">
                        <summary>Контакты и описание покупки</summary>
                        <dl className="ws-facts checkout-facts">
                          <div>
                            <dt>ФИО</dt>
                            <dd>{member.fullName || member.name}</dd>
                          </div>
                          <div>
                            <dt>Номер карты</dt>
                            <dd>{memberCards[member.id] || String(member.id + 99000)}</dd>
                          </div>
                          <div>
                            <dt>Контакты</dt>
                            <dd>
                              {member.phone} · {member.email}
                            </dd>
                          </div>
                          <div>
                            <dt>Наименование покупки</dt>
                            <dd>{item.name}</dd>
                          </div>
                          <div>
                            <dt>Описание</dt>
                            <dd>{item.short || item.description || item.name}</dd>
                          </div>
                          <div>
                            <dt>Цена за единицу</dt>
                            <dd>{money(item.price)}</dd>
                          </div>
                        </dl>
                      </details>
                    </div>
                    <div className="checkout-settings ws-stack">
                      <div className="ws-fields">
                        {category === 'Товары' && (
                          <label className="form-field">
                            <span>Количество</span>
                            <input
                              type="number"
                              min="1"
                              max="999"
                              step="1"
                              value={quantity}
                              disabled={done}
                              onChange={(e) => {
                                setQuantity(e.target.value);
                                setError('');
                              }}
                            />
                          </label>
                        )}
                        <label className="form-field">
                          <span>Применить скидку</span>
                          <Select
                            value={discount}
                            disabled={done}
                            onChange={(e) => {
                              setDiscount(e.target.value);
                              setError('');
                            }}
                          >
                            <option value="0">Без скидки</option>
                            <option value="5">5% · пример</option>
                            <option value="10">10% · пример</option>
                            <option value="15">15% · пример</option>
                          </Select>
                        </label>
                      </div>
                      <label className="ws-checkbox">
                        <input
                          type="checkbox"
                          checked={printReceipt}
                          disabled={done}
                          onChange={(e) => setPrintReceipt(e.target.checked)}
                        />
                        Печатать чек
                      </label>

                      <label className="form-field mobile-payment-method">
                        <span>Способ оплаты</span>
                        <Select
                          value={method}
                          disabled={done}
                          onChange={(event) => {
                            setMethod(event.target.value as PaymentMethod);
                            setError('');
                          }}
                        >
                          {paymentMethods.map((value) => (
                            <option key={value}>{value}</option>
                          ))}
                        </Select>
                      </label>
                      <div className="payment-methods" role="radiogroup" aria-label="Способ оплаты">
                        {paymentMethods.map((value, index) => {
                          const Icon = methodIcons[index];
                          return (
                            <button
                              role="radio"
                              aria-checked={method === value}
                              disabled={done}
                              key={value}
                              onKeyDown={(event) => {
                                const direction = ['ArrowRight', 'ArrowDown'].includes(event.key)
                                  ? 1
                                  : ['ArrowLeft', 'ArrowUp'].includes(event.key)
                                    ? -1
                                    : 0;
                                if (!direction) return;
                                event.preventDefault();
                                const next =
                                  (index + direction + paymentMethods.length) %
                                  paymentMethods.length;
                                setMethod(paymentMethods[next]);
                                setError('');
                                event.currentTarget.parentElement
                                  ?.querySelectorAll<HTMLButtonElement>('[role="radio"]')
                                  [next]?.focus();
                              }}
                              tabIndex={method === value ? 0 : -1}
                              onClick={() => {
                                setMethod(value);
                                setError('');
                              }}
                            >
                              <Icon size={22} />
                              <strong>{value}</strong>
                              <small>
                                {value === 'Составная оплата'
                                  ? 'Несколько способов в одной покупке'
                                  : value === 'В кредит'
                                    ? 'Зафиксировать задолженность'
                                    : value === 'Подарочная карта'
                                      ? 'Списать с демонстрационного остатка'
                                      : 'Зачисление и подготовка чека'}
                              </small>
                            </button>
                          );
                        })}
                      </div>
                      {method === 'Составная оплата' && (
                        <div className="ws-fields">
                          {(['cash', 'card', 'gift', 'credit'] as const).map((key, index) => (
                            <label className="form-field" key={key}>
                              <span>
                                {
                                  [
                                    'Наличными, ₽',
                                    'Безналично, ₽',
                                    'Подарочной картой, ₽',
                                    'В долг, ₽',
                                  ][index]
                                }
                              </span>
                              <input
                                type="number"
                                min="0"
                                step="0.01"
                                disabled={done}
                                value={parts[key]}
                                onChange={(e) => {
                                  setParts({ ...parts, [key]: Number(e.target.value) });
                                  setError('');
                                }}
                              />
                            </label>
                          ))}
                        </div>
                      )}
                      {(method === 'Подарочная карта' ||
                        (method === 'Составная оплата' && parts.gift > 0)) && (
                        <label className="form-field">
                          <span>Подарочная карта</span>
                          <Select
                            value={giftId}
                            disabled={done}
                            onChange={(e) => {
                              setGiftId(e.target.value);
                              setError('');
                            }}
                          >
                            <option value="">Выберите демокарту</option>
                            {(data['gift-cards'] || [])
                              .filter((row) => row.status === 'Активна')
                              .map((row) => (
                                <option key={row.id} value={row.id}>
                                  {row.name} · остаток {money(row.balance)}
                                </option>
                              ))}
                          </Select>
                        </label>
                      )}
                      {(method === 'В кредит' ||
                        (method === 'Составная оплата' && parts.credit > 0)) && (
                        <Notice>
                          Неоплаченная часть будет записана как задолженность выбранного клиента.
                          Это демонстрационный сценарий.
                        </Notice>
                      )}

                      {(error || calculationError) && (
                        <p className="ws-error" role="alert">
                          {error || calculationError}
                        </p>
                      )}
                    </div>
                  </div>
                  <div className="checkout-submit" ref={submitArea}>
                    <div className="checkout-total">
                      <span>Итого к оплате</span>
                      <strong>{money(pricing.total)}</strong>
                      {pricing.discount > 0 && (
                        <small>
                          Скидка: {money(pricing.discount)} · до скидки {money(pricing.base)}
                        </small>
                      )}
                    </div>
                    <div className="ws-actions">
                      <Button disabled={done || !!calculationError} onClick={confirm}>
                        {done ? 'Продажа сохранена' : 'Подтвердить демопродажу'}
                      </Button>
                      {done && receipt && (
                        <Button variant="secondary" onClick={() => setReceiptOpen(true)}>
                          Показать чек
                        </Button>
                      )}
                    </div>
                    <small className="form-note">Без реальной оплаты и печати</small>
                    {done && (
                      <Notice tone="success">
                        Продажа сохранена в кассе и финансах клиента.
                        {isPlan && ' Карта добавлена клиенту.'}
                        {debt > 0 && ` Задолженность: ${money(debt)}.`}
                      </Notice>
                    )}
                  </div>
                </>
              ) : (
                <Empty
                  title="Выберите клиента и покупку"
                  text="Затем здесь появятся данные и варианты оплаты."
                />
              )}
            </div>
          </section>
        )}
      </div>
      {receiptOpen && receipt && (
        <Modal
          title="Демонстрационный чек"
          subtitle="Не является фискальным документом"
          onClose={closeReceipt}
        >
          <dl className="ws-facts">
            <div>
              <dt>Клиент</dt>
              <dd>{receipt.client}</dd>
            </div>
            <div>
              <dt>Карта</dt>
              <dd>{receipt.card}</dd>
            </div>
            <div>
              <dt>Покупка</dt>
              <dd>
                {receipt.name} × {receipt.quantity}
              </dd>
            </div>
            <div>
              <dt>Скидка</dt>
              <dd>{money(receipt.discountAmount)}</dd>
            </div>
            <div>
              <dt>Итого</dt>
              <dd>{money(receipt.total)}</dd>
            </div>
            <div>
              <dt>Оплата</dt>
              <dd>{receipt.method}</dd>
            </div>
            <div>
              <dt>Задолженность</dt>
              <dd>{money(receipt.creditAmount)}</dd>
            </div>
          </dl>
        </Modal>
      )}
    </div>
  );
}
